
// Main Script































// Don't worry about this yet
var myDynamicHTML = '<div class="movie">' +
                        '<h1>{{ title }} - {{ rating }}</h1>' +
                        '<img src="{{ image }}"/>' +
                        '<p>{{ synopsis }}</p>' +
                    '</div>';

// Let's write a function, that accepts a string. This function will return a new function
// that we can use to then pass in variables, which will be rendered and returned as HTML








