

Utility = function () {}

Utility.prototype = {

    jsonp: function (url, success) {

    },

    bind: function (fn, context) {
        return function () {
            return fn.apply(context, arguments);
        }
    },

    template: function (htmlString) {
        
    },

    createElement: function (htmlString) {
        
    }

}

