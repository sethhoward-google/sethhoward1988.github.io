
var App = function () {
    // Constructor
    this.init();

}

App.prototype = {

    elString:'<div class="app">' +
                '<input type="text" placeholder="search for movies..." />' +
                '<div class="results"></div>' +
            '</div>',

    movieElString:  '<div class="movie">' +
                        '<h1>{{title}} - {{rating}}</h1>' +
                        '<img src="{{image}}"/>' +
                        '<p>{{synopsis}}</p>' +
                    '</div>',

    init: function () {
        this.util = new Utility;

    }

}
